package SpeedDate;


import javax.swing.JOptionPane;
import java.util.Scanner;
/**
 * Tester to find the dates of the 4th of July, Thanksgiving, and the number
 * of days between two dates using user-input.
 * @author James Rocks
 */

public class SpeedDatingTester {

    public static void main(String[] args)
    {
        JOptionPane.showMessageDialog(null, "To find the 4th of July for the"
                                + " next 10 years:");
        
        SpeedDating one = new SpeedDating();

        String fourthOfJulyYear = JOptionPane.showInputDialog("Enter first year");

        int startYear = Integer.parseInt(fourthOfJulyYear);

        System.out.println("The fourth of July falls on the following days: ");

        one.print4thOfJulys(startYear);

        
        
        JOptionPane.showMessageDialog(null, "To find out what day Thanksgiving"
                    + " falls on:");
        for (int c = 0; c < 2; c++)
        {
            SpeedDating dayOfThanks = new SpeedDating();

            String thanksgiving = JOptionPane.showInputDialog("Enter a year"
                        + " for Thanksgiving");

            int year = Integer.parseInt(thanksgiving);

            System.out.println("Thanksgiving is on " + 
                    dayOfThanks.getThanksgiving(year).getLongDate());
        }




        JOptionPane.showMessageDialog(null, "To find the number of days between"
                            + " two dates:");

        SpeedDating dayCount = new SpeedDating();

        String first = JOptionPane.showInputDialog("What's the start date? "
                + "(mm dd yyyy)");



        Scanner beginning = new Scanner(first);

        int firstMonth = beginning.nextInt();
        int firstDay = beginning.nextInt();
        int firstYear = beginning.nextInt();

        Date start = new Date(firstMonth, firstDay, firstYear);

        System.out.println("You've entered " + start.getMediumDate());


        String last = JOptionPane.showInputDialog("What's the end date? "
                + "(mm dd yyyy)");

        Scanner ending = new Scanner(last);

        int lastMonth = ending.nextInt();
        int lastDay = ending.nextInt();
        int lastYear = ending.nextInt();

        Date end = new Date(lastMonth, lastDay, lastYear);

        System.out.println("You've entered " + end.getMediumDate());



        System.out.println("There are " + dayCount.getDaysBetween(start, end)
                + " days in between these dates.");

    }
}